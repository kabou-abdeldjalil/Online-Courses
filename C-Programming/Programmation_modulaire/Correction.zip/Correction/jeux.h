
#define NB_JEUX 3
#define SORTIE 0
#define MORPION 1
#define MASTERMIND 2
#define PENDU 3

void afficherBibliotheque();
void selectionJeu(int);
