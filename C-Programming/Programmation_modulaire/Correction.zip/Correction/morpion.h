void morpion();

void dessinerGrille(char [][3]);
int saisieValide(char [][3], int , int  );
void saisieUtilisateur(char [][3], char , int* , int* );

int victoire(char [][3], char );
int grillePleine(char [][3]);
